namespace Finance;

public class EducationLoan
{
    [MaxDuration]
    public float Common(double amount, int period) => 6.0f;

    public float Masters(double amount, int period) => 6.5f;

}