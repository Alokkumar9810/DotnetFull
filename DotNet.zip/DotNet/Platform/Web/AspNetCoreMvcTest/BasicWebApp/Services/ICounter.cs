namespace BasicWebApp.Services;

public interface ICounter
{
    int CountNext(string key);
}
